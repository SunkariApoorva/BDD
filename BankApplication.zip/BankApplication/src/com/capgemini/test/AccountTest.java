package com.capgemini.test;

import org.junit.Before;
import org.junit.Test;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;

import com.capgemini.exceptions.InsufficientBalanceException;
import com.capgemini.exceptions.InsufficientInitialAmountException;
import com.capgemini.exceptions.InvalidAccountNumberException;
import com.capgemini.model.Account;
import com.capgemini.repository.AccountRepository;
import com.capgemini.service.AccountService;
import com.capgemini.service.AccountServiceImpl;
import static org.junit.Assert.assertEquals;
import static org.mockito.Mockito.when;

import java.util.Scanner;

import javax.naming.InsufficientResourcesException;
public class AccountTest {

	AccountService accountService;
	
	@Mock
	AccountRepository accountRepository;
	@Before
	public void setUp() throws Exception {
		MockitoAnnotations.initMocks(this);
		
		accountService = new AccountServiceImpl(accountRepository);
	}

	/*
	 * create account
	 * 1.when the amount is less than 500 then system should throw exception
	 * 2.when the valid info is passed account should be created successfully
	 */
	
	@Test(expected=com.capgemini.exceptions.InsufficientInitialAmountException.class)
	public void whenTheAmountIsLessThan500SystemShouldThrowException() throws InsufficientInitialAmountException
	{
		accountService.createAccount(101, 400);
	}
	
	@Test
	public void whenTheValidInfoIsPassedAccountShouldBeCreatedSuccessfully() throws InsufficientInitialAmountException
	{
		Account account =new Account();
		account.setAccountNumber(101);
		account.setAmount(5000);
		when(accountRepository.save(account)).thenReturn(true);
		assertEquals(account, accountService.createAccount(101, 5000));
	}
	@Test
	public void withdrawal1() throws InvalidAccountNumberException, InsufficientBalanceException {
		Account account = new Account();
		account.setAccountNumber(1001);
		when(accountRepository.searchAccount(account.getAccountNumber())).thenReturn(account);
		accountService.withdrawal(1001,5000);
		assertEquals(1001, account.getAccountNumber());
	}
	@Test
	public void withdrawal() throws InsufficientBalanceException {
		
		Account account = new Account();
		assertEquals(3000, accountService.withdrawal(101,5000));
		
	}
	@Test
	public void deposit1() throws InvalidAccountNumberException, InsufficientResourcesException {
		Account account = new Account();
		account.setAccountNumber(1001);
		when(accountRepository.searchAccount(account.getAccountNumber())).thenReturn(account);
		accountService.deposit(1001,5000);
		assertEquals(1001, account.getAccountNumber());
		
		
	}
	@Test
	public void deposit() throws InsufficientResourcesException {
		Account account = new Account();
		assertEquals(13000, accountService.deposit(102,5000));
	}
	


}
