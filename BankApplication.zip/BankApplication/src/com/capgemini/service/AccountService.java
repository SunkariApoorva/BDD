package com.capgemini.service;

import javax.naming.InsufficientResourcesException;

import com.capgemini.exceptions.InsufficientBalanceException;
import com.capgemini.exceptions.InsufficientInitialAmountException;
import com.capgemini.model.Account;

public interface AccountService {

	Account createAccount(int accountNumber, int amount) throws InsufficientInitialAmountException;
	public int withdrawal(int accountNumber,int amount) throws InsufficientBalanceException;
	public int deposit(int accountNumber,int amount)throws InsufficientResourcesException;

}